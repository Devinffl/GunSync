export const processPayment = async (cart, cardDetails) => {
  return { success: true, transactionId: 'MOCK_TX_001' };
};