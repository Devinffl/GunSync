export const fetchSerializedInventory = async () => {
  return [
    { id: 'FB001', name: 'Glock 19 Gen 5', serial: 'ABC123456', status: 'In Stock' },
    { id: 'FB002', name: 'Smith & Wesson M&P 15', serial: 'XYZ987654', status: 'Sold' }
  ];
};