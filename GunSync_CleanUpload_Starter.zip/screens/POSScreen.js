import React from 'react';
import { View, Text, Button, Alert } from 'react-native';
import { processPayment } from '../services/PayrocService';

export default function POSScreen() {
  const handleCheckout = async () => {
    const result = await processPayment([], {});
    if (result.success) {
      Alert.alert('Payment Successful', `Transaction ID: ${result.transactionId}`);
    } else {
      Alert.alert('Payment Failed', 'Please try again.');
    }
  };

  return (
    <View style={{ padding: 20 }}>
      <Text style={{ fontSize: 18 }}>POS Checkout Screen</Text>
      <Button title="Simulate Payment" onPress={handleCheckout} />
    </View>
  );
}