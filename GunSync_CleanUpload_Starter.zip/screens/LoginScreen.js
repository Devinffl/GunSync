import React from 'react';
import { View, Text, Button } from 'react-native';

export default function LoginScreen({ navigation }) {
  return (
    <View style={{ padding: 20 }}>
      <Text>Login Screen (Firebase Auth will go here)</Text>
      <Button title="Log In" onPress={() => navigation.navigate('Inventory')} />
    </View>
  );
}