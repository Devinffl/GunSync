import React, { useEffect, useState } from 'react';
import { View, Text, Button, FlatList } from 'react-native';
import { fetchSerializedInventory } from '../services/FastBoundAPI';

export default function InventoryScreen({ navigation }) {
  const [inventory, setInventory] = useState([]);

  useEffect(() => {
    const loadInventory = async () => {
      const data = await fetchSerializedInventory();
      setInventory(data);
    };
    loadInventory();
  }, []);

  return (
    <View style={{ padding: 20 }}>
      <Text style={{ fontWeight: 'bold', fontSize: 18 }}>Serialized Inventory</Text>
      <FlatList
        data={inventory}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <Text>{item.name} - {item.serial} - {item.status}</Text>
        )}
      />
      <Button title="Go to POS" onPress={() => navigation.navigate('POS')} />
    </View>
  );
}